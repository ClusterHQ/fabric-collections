# vim: ai ts=4 sts=4 et sw=4 ft=python fdm=indent et foldlevel=0
from time import sleep

def sleep_for_one_minute():
    sleep(60)

